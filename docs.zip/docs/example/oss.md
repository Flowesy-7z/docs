# 阿里云 OSS

> 注意：目前使用该对象存储
<a target="_blank" rel="noopener noreferrer">
<img  src="/img/example/oss-01.png"   alt="AikanPro"/> </a>
<a target="_blank" rel="noopener noreferrer">
<img  src="/img/example/oss-02.png"   alt="AikanPro"/> </a>

