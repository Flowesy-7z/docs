# 腾讯云 COS


:::caution

注意：如果你使用了自定义域名，且在腾讯云开启了回源鉴权，那么需要在 AikanPro 中要使用自定义域名，否则会导致无法正常使用。（回源鉴权表示无论是是否是私有空间，通过 cdn 域名下载文件都不需要增加任何签名，也可以理解为变成了公共下载，这时候带签名下载反而会报错。）

:::


<a target="_blank" rel="noopener noreferrer">
<img  src="/img/example/tencent-01.png"  alt="AikanPro"/> </a>
<a target="_blank" rel="noopener noreferrer">
<img  src="/img/example/tencent-02.png"    alt="AikanPro"/> </a>

