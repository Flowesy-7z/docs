---
sidebar_label: 华为云 OBS
---

# 华为云 OBS

<a target="_blank" rel="noopener noreferrer">
<img  src="/img/example/huawei-01.png"    alt="AikanPro"/> </a>
<a target="_blank" rel="noopener noreferrer">
<img  src="/img/example/huawei-02.png"    alt="AikanPro"/> </a>
<a target="_blank" rel="noopener noreferrer">
<img  src="/img/example/huawei-03.png"    alt="AikanPro"/> </a>
