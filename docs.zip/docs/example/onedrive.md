# OneDrive

国际版，个人版，E3，E5，A1等，除了世纪互联外都属于这个类别。

[点击获取 OneDrive 访问令牌](https://zfile.jun6.net/onedrive/authorize)
