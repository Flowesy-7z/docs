# SharePoint 世纪互联

[获取 OneDrive 访问令牌](https://zfile.jun6.net/onedrive/china-authorize)
